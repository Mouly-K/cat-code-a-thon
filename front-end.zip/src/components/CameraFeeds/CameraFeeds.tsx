import { useState, useRef, useCallback, useEffect } from "react";
import { BiChevronDown } from "react-icons/bi";
import Webcam from "react-webcam";
import "./camerafeeds.css";

import Dropdown from "../Dropdown/Dropdown";

const videoConstraints = {
  facingMode: "user",
};

export default function CameraFeeds() {
  const webcamRef = useRef<Webcam>(null);

  //   const capture = useCallback(() => {
  //     const imageSrc = webcamRef?.current?.getScreenshot();
  //   }, [webcamRef]);

  const [selectedDevice, setSelectedDevice] = useState<any>({});
  const [devices, setDevices] = useState<any>([]);

  const handleDevices = useCallback(
    (mediaDevices: any) => {
      const videoDevices = mediaDevices.filter(
        ({ kind }: { kind: string }) => kind === "videoinput"
      );
      setDevices(videoDevices);
      setSelectedDevice(videoDevices[0]);
    },
    [setDevices]
  );

  useEffect(() => {
    navigator.mediaDevices.enumerateDevices().then(handleDevices);
  }, [handleDevices]);

  useEffect(() => {
    console.log(devices);
  }, [devices]);

  return (
    <div className="camera-feeds-container">
      <Dropdown
        dropDownLabel="Cameras"
        options={devices.map((device: any) => device.label)}
        selectedOption={selectedDevice.label}
        setSelectedOption={(option: string) => {
          setSelectedDevice(
            devices.find((device: any) => device.label === option)
          );
        }}
      >
        <button className="dropdown-button">
          {selectedDevice.label}
          <BiChevronDown />
        </button>
      </Dropdown>
      <div className="camera-feeds">
        {devices.map((device: any, index: number) => (
          <div
            key={index}
            data-visible={device.label === selectedDevice.label}
            className="camera-feed"
          >
            <Webcam
              ref={webcamRef}
              audio={false}
              videoConstraints={{
                ...videoConstraints,
                deviceId: device.deviceId,
              }}
              screenshotFormat="image/jpeg"
            />
          </div>
        ))}
      </div>
    </div>
  );
}
