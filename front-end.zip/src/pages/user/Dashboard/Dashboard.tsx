import "./dashboard.css";

import CameraFeeds from "../../../components/CameraFeeds/CameraFeeds";
import Header from "../../../components/Header/Header";

export default function Dashboard() {
  return (
    <div className="dashboard-container">
      <Header />
      <div className="section">
        <div className="left">
          <section>
            <p>Overview</p>
            <h2>GMC Hummer EV</h2>
          </section>
          <div className="card-container"></div>
        </div>
        <div className="right">
          <CameraFeeds />
        </div>
      </div>
    </div>
  );
}
