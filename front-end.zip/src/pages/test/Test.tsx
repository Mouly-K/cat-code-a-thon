export default function Test() {
  return (
    <div>
      <label className="save-changes button noselect">
        <p>Upload Report</p>
      </label>
    </div>
  );
}
